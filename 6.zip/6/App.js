import React,{Component} from 'react';
import {View,Text, Image, ScrollView, StyleSheet} from 'react-native';
export default class App extends Component{
  render(){
    return(
      <ScrollView>
      <View style = {styles.container}>
      <Image 
      source={{uri:'https://scontent.fmnl30-1.fna.fbcdn.net/v/t39.30808-6/279617530_703157527556404_4588312857839016206_n.jpg?_nc_cat=111&ccb=1-7&_nc_sid=833d8c&_nc_eui2=AeGb9W7LQREzLajtIJnIEQuu5wFwMeW7ncrnAXAx5budyuonivfCtpsdI4iLPTb0uYKEif4zkLgOB5ABATmRkXH0&_nc_ohc=inSc0WhrDDwQ7kNvgE4VFej&_nc_ht=scontent.fmnl30-1.fna&oh=00_AYA7jE7qxWZUFuqk1NNeWEKwPpcyoaIIzgFNcwv6JWidlw&oe=66D4406B'}}
      style ={{width:200, height:200}}
      />
      <Text style={styles.text}>Yuan Ortigueras</Text>
       <Text style={styles.text}>Bs Tambay</Text>
        <Text style={styles.text}>3rd Year College</Text>
      </View>
      <View style={styles.container}>
      <Image
    source={{uri:'https://scontent.fmnl30-1.fna.fbcdn.net/v/t39.30808-6/378231250_1006531023885718_1671293598991655953_n.jpg?_nc_cat=102&ccb=1-7&_nc_sid=127cfc&_nc_eui2=AeGvCBf3f4kJ9uG2LZWV11rx52WF9213QCHnZYX3bXdAITfdPo-baoaTnZXI6_nYeBfEC7xjRo6baVTDQV6Bj3oM&_nc_ohc=Uve9ZMN-eAoQ7kNvgGx2DSK&_nc_ht=scontent.fmnl30-1.fna&oh=00_AYCZbcL-OF37byYS_hzYHf7cCGLg-Qetnul5WK0IrFfIKg&oe=66D46AD8'}}
      style={{width:200, height:200}}
      />
      <Text style={styles.text}>Ang Aking Kaibigang si Marc Neil Sababan</Text>
      </View>
      </ScrollView>
    );
  }
}
const styles = StyleSheet.create({
  container:{
    flex:1,
    alignItems:'center',
    justifyContent:'center',
    marginVertical:20,
  },
  text:{
    fontSize:24,
    color:'purple',
    fontWeight:'bold',
    textAlign:'center',
    marginVertical:10,
  },
});

