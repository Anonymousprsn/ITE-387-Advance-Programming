import React,{Component} from 'react';
import {View,Text, Image, ScrollView, StyleSheet} from 'react-native';
export default class App extends Component{
  render(){
    return(
      <ScrollView>
      <View style = {styles.container}>
      <Image 
      source={{uri:'https://th.bing.com/th/id/OIP.QVo9sEefaCn3pY63VC7V9gHaMC?rs=1&pid=ImgDetMain'}}
      style ={{width:200, height:200}}
      />
      <Text></Text>
      </View>
      <View style={styles.container}>
      <Image
    source={{uri:'https://th.bing.com/th/id/OIP.xhh1AO-XDNtaOsn_atUzvQHaHa?rs=1&pid=ImgDetMain'}}
      style={{width:200, height:200}}
      />
      <Text style={styles.text}>Mariah Queen Arceta</Text>
      </View>
      </ScrollView>
    );
  }
}
const styles = StyleSheet.create({
  container:{
    flex:1,
    alignItems:'center',
    justifyContent:'center',
    marginVertical:20,
  },
  text:{
    fontSize:24,
    fontWeight:'bold',
    textAlign:'center',
    marginVertical:10,
  },
});

