import React, {useState} from 'react';
import {StyleSheet, Text, View, TextInput,Button,Image} from 'react-native';
export default function App(){
  const [weight,setWeight] = useState('');
  const [age, setAge] = useState('');
  const [goal, setGoal] = useState('');

  const calculatedGoal =() =>{
    let calculatedGoal = "";
    if (weight >200 && age > 53){
      calculatedGoal = "Your daily calorie goal is X. Its recommended to do low-impact exercise like swimming and walking";
    }else{
      calculatedGoal = "Your daily calorie goal is X.";
    }
    setGoal(calculatedGoal);
  }
  return(
    <View style = {styles.container}>
    <Image source={{url:'https://th.bing.com/th/id/OIP.X3mfeI7lW-x1NvHx8AZwAAHaHa?rs=1&pid=ImgDetMain'}}style={{fontSize:200, height:200}}/>
    <Text style ={{fontSize:40, color:'pink'}}>Goal Tracker</Text>

    <Text>Weight:</Text>
    <TextInput
    style={styles.input}
    onChangeText={(text) => setWeight(text)}
    value={weight}
    keyboardType="numeric"
    />
    <Text>Age:</Text>
    <TextInput
    style={styles.input}
    onChangeText={(text) => setAge(text)}
    value={age}
    keyboardType="numeric"
    />
    <Button
    title="Calculate Goal"
    onPress={calculatedGoal}
    />
    <Text>{goal}</Text>
    </View>
  );
}
const styles= StyleSheet.create({
  container:{
    flex:1,
    backgroundColor:'#fff',
    alignItems:'center',
    justifyContent:'center',

  },
  input:{
    borderWidth:1,
    borderColor:'#ccc',
    padding: 8,
    margin:10,
    width:200,
  },
});